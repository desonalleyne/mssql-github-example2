
EXECUTE InsertMovie
  @Movie = 'Rollback To The Future',
  @GenreID = 7

EXECUTE InsertMovie
  @Movie = 'Server Room with a View',
  @GenreID = 7

EXECUTE InsertMovie
  @Movie = 'Full Metal Bracket',
  @GenreID = 7

