
execute InsertMovieReview @EmployeeID = 9, @MovieID = 9, @Stars = 5
execute InsertMovieReview @EmployeeID = 9, @MovieID = 10, @Stars = 5
execute InsertMovieReview @EmployeeID = 9, @MovieID = 11, @Stars = 5
execute InsertMovieReview @EmployeeID = 9, @MovieID = 12, @Stars = 5
execute InsertMovieReview @EmployeeID = 9, @MovieID = 14, @Stars = 5
execute InsertMovieReview @EmployeeID = 9, @MovieID = 15, @Stars = 5
execute InsertMovieReview @EmployeeID = 9, @MovieID = 16, @Stars = 5

execute InsertMovieReview @EmployeeID = 10, @MovieID = 9, @Stars = 5
execute InsertMovieReview @EmployeeID = 10, @MovieID = 10, @Stars = 5
execute InsertMovieReview @EmployeeID = 10, @MovieID = 11, @Stars = 5
execute InsertMovieReview @EmployeeID = 10, @MovieID = 12, @Stars = 5
execute InsertMovieReview @EmployeeID = 10, @MovieID = 14, @Stars = 4
execute InsertMovieReview @EmployeeID = 10, @MovieID = 15, @Stars = 4
execute InsertMovieReview @EmployeeID = 10, @MovieID = 16, @Stars = 4

execute InsertMovieReview @EmployeeID = 11, @MovieID = 9, @Stars = 5
execute InsertMovieReview @EmployeeID = 11, @MovieID = 10, @Stars = 5
execute InsertMovieReview @EmployeeID = 11, @MovieID = 11, @Stars = 5
execute InsertMovieReview @EmployeeID = 11, @MovieID = 12, @Stars = 5
execute InsertMovieReview @EmployeeID = 11, @MovieID = 14, @Stars = 3
execute InsertMovieReview @EmployeeID = 11, @MovieID = 15, @Stars = 3
execute InsertMovieReview @EmployeeID = 11, @MovieID = 16, @Stars = 3

